package com.mayaai.assistant

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val bg = Color.rgb(8, 8, 20)
    private val panel = Color.rgb(23, 20, 43)
    private val purple = Color.rgb(177, 125, 255)
    private val blue = Color.rgb(75, 170, 255)
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var voicePicker: Spinner
    private var tts: TextToSpeech? = null
    private var speakEnabled = true
    private val executor = Executors.newSingleThreadExecutor()
    // Replace only with your own HTTPS backend. Never place an API key in this APK.
    private val backendUrl = "https://YOUR_BACKEND_DOMAIN.example/chat"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
        addMessage("MAYA", "Hello! I'm MAYA AI. Offline commands are ready. Connect a secure backend to enable online AI.")
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 22, 18, 14)
            setBackgroundColor(bg)
        }
        val header = TextView(this).apply {
            text = "✦  MAYA AI"; textSize = 25f; setTextColor(purple)
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "● OFFLINE READY"; textSize = 12f; setTextColor(blue)
            gravity = Gravity.CENTER; setPadding(0, 7, 0, 16)
        }
        chat = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(chat); setFillViewport(true) }
        input = EditText(this).apply {
            hint = "Message MAYA..."; setHintTextColor(Color.LTGRAY); setTextColor(Color.WHITE)
            textSize = 16f; setSingleLine(true); setPadding(14, 12, 14, 12); setBackgroundColor(panel)
        }
        val send = Button(this).apply {
            text = "SEND"; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(103, 65, 180))
            setOnClickListener { sendMessage() }
        }
        val mic = Button(this).apply {
            text = "🎙"; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(37, 65, 115))
            setOnClickListener { startVoiceInput() }
        }
        voicePicker = Spinner(this).apply { setBackgroundColor(panel) }
        val voice = Button(this).apply {
            text = "VOICE ON"; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(42, 42, 75))
            setOnClickListener { speakEnabled = !speakEnabled; text = if (speakEnabled) "VOICE ON" else "VOICE OFF" }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(input, LinearLayout.LayoutParams(0, -2, 1f)); addView(send)
        }
        val tools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            addView(mic); addView(voicePicker, LinearLayout.LayoutParams(0, -2, 1f)); addView(voice)
        }
        root.addView(header); root.addView(status)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(row); root.addView(tools)
        setContentView(root)
    }

    private fun addMessage(who: String, message: String) {
        val tv = TextView(this).apply {
            text = "$who\n$message"; textSize = 15f; setTextColor(Color.WHITE)
            setPadding(14, 12, 14, 12); setBackgroundColor(if (who == "YOU") Color.rgb(29, 37, 68) else panel)
        }
        chat.addView(tv, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 7, 0, 7) })
    }

    private fun sendMessage() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText(""); addMessage("YOU", text)
        val local = offlineReply(text)
        if (local != null) { addMessage("MAYA", local); speak(local); return }
        status.text = "● CONNECTING..."
        executor.execute {
            val reply = askBackend(text)
            runOnUiThread {
                status.text = if (reply.startsWith("Online backend not configured")) "● OFFLINE READY" else "● ONLINE RESPONSE"
                addMessage("MAYA", reply); speak(reply)
            }
        }
    }

    private fun offlineReply(text: String): String? {
        val q = text.lowercase(Locale.ROOT)
        return when {
            q.contains("hello") || q.contains("namaste") || q.contains("नमस्ते") -> "Hello! मैं MAYA AI हूँ। अभी offline mode में हूँ।"
            q.contains("time") || q.contains("समय") -> "फोन का समय: " + java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(java.util.Date())
            q.contains("date") || q.contains("तारीख") -> "आज की तारीख: " + java.text.SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()).format(java.util.Date())
            q.contains("who are you") || q.contains("तुम कौन") -> "मैं MAYA AI हूँ, आपका personal assistant।"
            q.contains("help") || q.contains("मदद") -> "Offline commands: hello, time, date, who are you, help."
            else -> null
        }
    }

    private fun askBackend(message: String): String {
        if (backendUrl.contains("YOUR_BACKEND_DOMAIN")) return "Online backend not configured. अभी offline commands इस्तेमाल करें।"
        var c: HttpURLConnection? = null
        return try {
            c = (URL(backendUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 15000; readTimeout = 20000
                doOutput = true; setRequestProperty("Content-Type", "application/json")
            }
            c.outputStream.use { it.write(JSONObject().put("message", message).toString().toByteArray(Charsets.UTF_8)) }
            val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
            JSONObject(stream.bufferedReader().use { it.readText() }).optString("reply", "MAYA को जवाब नहीं मिला।")
        } catch (_: Exception) { "Online service उपलब्ध नहीं है। इंटरनेट और backend जाँचें।" }
        finally { c?.disconnect() }
    }

    private fun startVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to MAYA AI")
        }
        try { startActivityForResult(intent, 101) } catch (_: Exception) { addMessage("MAYA", "Speech recognition उपलब्ध नहीं है।") }
    }

    @Deprecated("Deprecated Android callback kept for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) { input.setText(spoken); sendMessage() }
        }
    }

    override fun onInit(code: Int) {
        if (code == TextToSpeech.SUCCESS) {
            val engine = tts ?: return
            engine.language = Locale("hi", "IN")
            val voices = engine.voices?.filter { it.locale.language in listOf("hi", "en") }?.sortedBy { it.name } ?: emptyList()
            runOnUiThread {
                voicePicker.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
                    if (voices.isEmpty()) listOf("Default device voice") else voices.map { "${it.name} (${it.locale.displayName})" })
                voicePicker.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                        voices.getOrNull(position)?.let { engine.voice = it }
                    }
                }
            }
        }
    }

    private fun speak(text: String) { if (speakEnabled) tts?.speak(text.take(900), TextToSpeech.QUEUE_FLUSH, null, "maya_reply") }
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); executor.shutdown(); super.onDestroy() }
}
