# MAYA AI Android starter
Kotlin Android starter for a black/purple/blue assistant UI, local time/date/help commands, speech input, and Android text-to-speech voice selection.

## Build
This project is intended to be built with Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17, and Android SDK platform/build-tools 35. A GitHub Actions workflow can build it in the cloud.

## Limitations
This is a starter project, not a compiled or tested APK. Online AI is not active until a secure HTTPS backend is deployed and its URL replaces the placeholder in `MainActivity.kt`. Never put an AI provider API key in an APK or public repository. Offline mode currently supports a few basic local commands, not a full offline language model. Available male/female voices depend on voices installed on the phone.
